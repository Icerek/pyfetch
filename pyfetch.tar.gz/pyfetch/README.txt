ENG:
FOR START:
unpack pyfetch.py

for Linux (debian/ubuntu based linux distros):
sudo apt update && sudo apt install python3-cpuinfo python3-psutil python3-pynvml -y

(if not work try for other distros way)

for other distros try:
python3 -m venv .venv
source .venv/bin/activate
then 
pip install py-cpuinfo psutil pynvml
(if doesnt work try enter pip3 install py-cpuinfo psutil pynvml)
python3 pyfetch.py


for Windows
Win+R
write cmd
in cmd enter pip install py-cpuinfo psutil pynvml
if an error occurs:
pip uninstall pynvml
pip install nvidia-ml-py


for MacOS
open terminal
enter in the terminal:
pip3 install py-cpuinfo psutil pynvml

(or pip install py-cpuinfo psutil pynvml)

if doesn't work, let me know
my discord: dizort21


РУС:
ДЛЯ НАЧАЛА
распакуйте pyfetch.zip

Для линукса (дистрибутивов основанных на Debian/Ubuntu):
sudo apt update && sudo apt install python3-cpuinfo python3-psutil python3-pynvml -y
(Если не работает попробуйте вариант ниже)

Для других дистрибутивов
python3 -m venv .venv
source .venv/bin/activate
потом уже
pip install py-cpuinfo psutil pynvml
(Если не работает попробуйте: pip3 install py-cpuinfo psutil pynvml)
python3 pyfetch.py

Для виндовс
Win+R
в окно напишите: cmd
в консоли введите: pip install py-cpuinfo psutil pynvml
Если выдало ошибку то попробуйте:
pip uninstall pynvml
pip install nvidia-ml-py


Для МакОС
Откройте терминал
Введите в терминал:
pip3 install py-cpuinfo psutil pynvml

(или просто pip install py-cpuinfo psutil pynvml)

если не работает напишите мне
Дискорд: dizort21
